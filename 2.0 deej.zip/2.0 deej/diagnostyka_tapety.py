# diagnostyka_tapety.py
import os

print("🔍 DIAGNOSTYKA TAPETY")
print("="*40)

# Sprawdź aktualny folder
print(f"Aktualny folder roboczy: {os.getcwd()}")

# Sprawdź zawartość folderu
print("\n📂 Zawartość folderu:")
try:
    files = os.listdir('.')
    for file in files:
        if os.path.isfile(file):
            size = os.path.getsize(file)
            print(f"  📄 {file} ({size} bajtów)")
        else:
            print(f"  📁 {file}/")
except Exception as e:
    print(f"❌ Błąd odczytu folderu: {e}")

# Sprawdź czy istnieje plik 1234
background_file = "1234"
print(f"\n🔍 Sprawdzam plik '{background_file}':")

if os.path.exists(background_file):
    print(f"  ✅ Plik istnieje")
    file_size = os.path.getsize(background_file)
    print(f"  📏 Rozmiar: {file_size} bajtów")
    
    # Sprawdź rozszerzenie
    import pathlib
    extension = pathlib.Path(background_file).suffix
    if extension:
        print(f"  🎨 Rozszerzenie: {extension}")
    else:
        print(f"  ⚠️  Brak rozszerzenia - to może być problem!")
        
    # Sprawdź czy to obraz
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff']
    if extension.lower() in image_extensions or extension == '':
        print(f"  🖼️  Prawdopodobnie jest to plik obrazu")
    else:
        print(f"  ❌ To może nie być plik obrazu")
        
else:
    print(f"  ❌ Plik '{background_file}' NIE istnieje")

# Sprawdź inne możliwe nazwy obrazów
print(f"\n🔍 Sprawdzam inne możliwe pliki obrazów:")
image_files = []
for file in files:
    if os.path.isfile(file):
        import pathlib
        extension = pathlib.Path(file).suffix.lower()
        image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff']
        if extension in image_extensions:
            image_files.append(file)

if image_files:
    for img_file in image_files:
        size = os.path.getsize(img_file)
        print(f"  ✅ {img_file} ({size} bajtów)")
else:
    print(f"  ❌ Nie znaleziono żadnych plików obrazów")

# Informacje pomocnicze
print(f"\n💡 WSKAZÓWKI:")
print(f"   • Upewnij się, że plik '{background_file}' jest w tym samym folderze")
print(f"   • Plik powinien być obrazem (PNG, JPG, BMP, itp.)")
print(f"   • Jeśli masz problem, spróbuj zmienić nazwę na 'background.png'")

print(f"\n🎯 AKTUALNA KONFIGURACJA:")
print(f"   Plik tapety w menu.py: '{background_file}'")